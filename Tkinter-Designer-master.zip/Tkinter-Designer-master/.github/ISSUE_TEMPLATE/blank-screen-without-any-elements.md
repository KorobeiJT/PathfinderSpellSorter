---
name: Blank Screen without any elements
about: Use this template if you are getting blank screen as output.
title: Blank Screen without any elements
labels: question
assignees: ''

---

How to Fix ?

This issue happens due to Incorrect Naming

Try to fix it by reading the instruction carefully.

If the issue still persists, create an issue with the following details included.

1. Error Message
2. Link to the Figma File
